import type {
  ColumnFiltersState,
  ColumnPinningState,
  ColumnSizingState,
  SortingState,
  VisibilityState
} from "@tanstack/react-table";
import type { DataTableFilter, DataTableSort, PersistedTableState } from "../core/types";

export function toTanStackSorting(sorting: ReadonlyArray<DataTableSort>): SortingState {
  return sorting.map((entry) => ({ id: entry.columnId, desc: entry.direction === "desc" }));
}

export function fromTanStackSorting(sorting: SortingState): ReadonlyArray<DataTableSort> {
  return sorting.map((entry) => ({
    columnId: entry.id,
    direction: entry.desc ? "desc" : "asc"
  }));
}

function stringifyFilterValue(value: DataTableFilter["value"]): string {
  if (value === null) {
    return "";
  }

  if (Array.isArray(value)) {
    return value.join(",");
  }

  return String(value);
}

export function toTanStackFilters(filters: ReadonlyArray<DataTableFilter>): ColumnFiltersState {
  return filters.map((entry) => ({ id: entry.columnId, value: stringifyFilterValue(entry.value) }));
}

export function fromTanStackFilters(filters: ColumnFiltersState): ReadonlyArray<DataTableFilter> {
  return filters.map((entry) => ({
    columnId: entry.id,
    op: "contains",
    value: String(entry.value)
  }));
}

export function toColumnVisibility(hiddenColumns: ReadonlyArray<string>): VisibilityState {
  const result: VisibilityState = {};
  for (const columnId of hiddenColumns) {
    result[columnId] = false;
  }
  return result;
}

export function fromColumnVisibility(visibility: VisibilityState): ReadonlyArray<string> {
  return Object.entries(visibility)
    .filter(([, isVisible]) => isVisible === false)
    .map(([columnId]) => columnId);
}

export function toColumnSizing(widths: Readonly<Record<string, number>>): ColumnSizingState {
  return { ...widths };
}

export function fromColumnSizing(sizing: ColumnSizingState): Readonly<Record<string, number>> {
  return { ...sizing };
}

export function toColumnPinning(
  left: ReadonlyArray<string>,
  right: ReadonlyArray<string>
): ColumnPinningState {
  return {
    left: [...left],
    right: [...right]
  };
}

export function fromColumnPinning(pinning: ColumnPinningState): {
  left: ReadonlyArray<string>;
  right: ReadonlyArray<string>;
} {
  return {
    left: pinning.left ?? [],
    right: pinning.right ?? []
  };
}

export function persistedStateToInternal(state: PersistedTableState): {
  sorting: SortingState;
  filters: ColumnFiltersState;
  columnOrder: string[];
  columnVisibility: VisibilityState;
  columnPinning: ColumnPinningState;
  columnSizing: ColumnSizingState;
} {
  return {
    sorting: toTanStackSorting(state.sorting),
    filters: toTanStackFilters(state.filters),
    columnOrder: [...state.columnOrder],
    columnVisibility: toColumnVisibility(state.hiddenColumns),
    columnPinning: toColumnPinning(state.pinLeft, state.pinRight),
    columnSizing: toColumnSizing(state.widths)
  };
}

export function internalToPersistedState(input: {
  sorting: SortingState;
  filters: ColumnFiltersState;
  columnOrder: string[];
  columnVisibility: VisibilityState;
  columnPinning: ColumnPinningState;
  columnSizing: ColumnSizingState;
}): PersistedTableState {
  const pinning = fromColumnPinning(input.columnPinning);

  return {
    sorting: fromTanStackSorting(input.sorting),
    filters: fromTanStackFilters(input.filters),
    columnOrder: [...input.columnOrder],
    pinLeft: pinning.left,
    pinRight: pinning.right,
    hiddenColumns: fromColumnVisibility(input.columnVisibility),
    widths: fromColumnSizing(input.columnSizing)
  };
}
