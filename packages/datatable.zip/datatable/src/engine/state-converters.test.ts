import { describe, expect, it } from "vitest";
import {
  fromColumnPinning,
  fromColumnSizing,
  fromColumnVisibility,
  fromTanStackFilters,
  fromTanStackSorting,
  internalToPersistedState,
  persistedStateToInternal,
  toColumnPinning,
  toColumnSizing,
  toColumnVisibility,
  toTanStackFilters,
  toTanStackSorting
} from "./state-converters";
import type { PersistedTableState } from "../core/types";

describe("state converters", () => {
  it("converts sorting both directions", () => {
    const sorting = [{ columnId: "name", direction: "desc" as const }];
    expect(fromTanStackSorting(toTanStackSorting(sorting))).toEqual(sorting);
  });

  it("converts filters to default contains mode", () => {
    const filters = [{ columnId: "status", op: "contains" as const, value: "todo" }];
    const tanstack = toTanStackFilters(filters);
    expect(tanstack).toEqual([{ id: "status", value: "todo" }]);
    expect(fromTanStackFilters(tanstack)).toEqual(filters);
  });

  it("converts visibility/pinning/sizing", () => {
    expect(fromColumnVisibility(toColumnVisibility(["amount"]))).toEqual(["amount"]);
    expect(fromColumnPinning(toColumnPinning(["name"], ["status"]))).toEqual({
      left: ["name"],
      right: ["status"]
    });
    expect(fromColumnSizing(toColumnSizing({ amount: 180 }))).toEqual({ amount: 180 });
  });

  it("round trips persisted state through internal table state", () => {
    const persisted: PersistedTableState = {
      sorting: [{ columnId: "name", direction: "asc" }],
      filters: [{ columnId: "status", op: "contains", value: "todo" }],
      columnOrder: ["name", "status"],
      pinLeft: ["name"],
      pinRight: [],
      hiddenColumns: ["status"],
      widths: { name: 240 }
    };

    const internal = persistedStateToInternal(persisted);
    expect(internalToPersistedState(internal)).toEqual(persisted);
  });
});
